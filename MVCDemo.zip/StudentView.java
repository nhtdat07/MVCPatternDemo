public class StudentView {
	public void printStudentDetails(Student st) {
		System.out.println("Student:\nName: " + st.getName() + "\nRollNo: "+ st.getRollNo());
	}
}
